import inventoryItem from '../../data/inventoryItem.json';

import { findAllUniqueSubCategories } from './dbUtils';

/**
 * Performs forward synthesis considering shortages.
 */
export const performItemSynthesisWithNeeds = (inventory, tieredMaterials, shortages) => {
    const synthesisResults = {};
    const rawNeedResults = {};
    //console.log(`[Debug] Initial inventoryItem : ${JSON.stringify(inventoryItem)}`);
    const uniqueSubCategories = findAllUniqueSubCategories(inventoryItem, shortages);

    console.log(`[Debug] Initial Unique SubCategories : ${uniqueSubCategories}`);

    for (const category of uniqueSubCategories) {

        //  console.log(`[Debug] Current Category: ${category}`);
        //  console.log(`[Debug] Initial tieredMaterials : ${JSON.stringify(tieredMaterials)}`);

        if (tieredMaterials.hasOwnProperty(category)) {
            const materialData = tieredMaterials[category];

            console.log(`[Debug] Initial Material Data : ${JSON.stringify(materialData)} / Category: ${category}`);

            for (const key in materialData) {

                if (materialData.hasOwnProperty(key)) {
                    const item = materialData[key];
                    //         console.log(`[Debug] Initial item in MD : ${JSON.stringify(item)}`);
                }

                const currentLevel = materialData[key];
                const nextLevel = materialData[+key + 1];
                if (!nextLevel) continue;
                //   console.log(`[Debug] Initial Level : ${JSON.stringify(currentLevel)} /   ${JSON.stringify(nextLevel)}`);

                const currentGameId = currentLevel.game_id;
                const nextGameId = nextLevel.game_id;

                console.log(`[Debug] Initial ID : ${currentGameId} /  ${nextGameId}`);
                // 첫 번째 : [Debug] Initial ID : 41100012 /  41100013
                // 두 번째 : [Debug] Initial ID : 41100012 /  41100013
                // 세 번째 : [Debug] Initial ID : 41100013 /  undefined

                const currentCount = inventory[currentGameId] || 0;
                const synthesisCount = currentLevel.synthesizable?.count || 1;
                const needed = shortages[currentGameId] || 0;

                //    console.log(`[Debug] Initial Current Count: ${currentCount}`);
                // 첫 번째 : [Debug] Initial Current Count: 55
                // 두 번째 : [Debug] Initial Current Count: 17
                // 세 번째 : [Debug] Initial Current Count: 1

                //    console.log(`[Debug] Initial Needed: ${needed}`);
                // 첫 번째 : [Debug] Initial Needed: 4
                // 두 번째 : [Debug] Initial Needed: 12
                // 세 번째 : [Debug] Initial Needed: 4

                const availableForSynthesis = Math.max(0, currentCount - needed);
                const synthesisQty = Math.floor(availableForSynthesis / synthesisCount);
                //  console.log("[Debug] Initial Synthesis Qty:", synthesisQty);
                // 첫 번째 : [Debug] Initial Synthesis Qty: 17
                // 두 번째 : [Debug] Initial Synthesis Qty: 1
                // 세 번째 : [Debug] Initial Synthesis Qty: 0

                if (synthesisQty > 0) {
                    inventory[currentGameId] -= synthesisQty * synthesisCount;
                    inventory[nextGameId] = (inventory[nextGameId] || 0) + synthesisQty;

                    //    console.log("[Debug] Initial Next Inventory:", inventory[nextGameId]);
                    // 첫 번째 : [Debug] Initial Next Inventory: 17
                    // 두 번째 : [Debug] Initial Next Inventory: 1
                    // 세 번째 : 못 들어옴

                    // synthesisResults[currentGameId] = {
                    //     used: synthesisQty * synthesisCount,
                    //     synthesized: synthesisQty,
                    // };

                    synthesisResults[nextGameId] = {
                        from: currentGameId,
                        used: synthesisQty * synthesisCount,
                        synthesized: synthesisQty,
                        rawNeed: shortages[nextGameId] ?? 0,  // 💡 여기가 핵심!

                    };
                }

                console.log("[Debug] Initial shortage Qty:", shortages[currentGameId]);
                rawNeedResults[currentGameId] = {
                    from: currentGameId,
                    rawNeed: shortages[currentGameId] ?? 0
                }
            }
        }

    }
    return { updatedInventory: inventory, synthesisResults, rawNeedResults };
};

/**
 * Performs backward conversion to handle surplus materials.
 */
export const backwardConversion = (inventory, tieredMaterials, shortages) => {
    const finalNeeds = { ...shortages };
    for (const category in tieredMaterials) {
        const materialData = tieredMaterials[category];
        const rarities = Object.keys(materialData).sort((a, b) => b - a); // Descending rarity
        for (const rarity of rarities) {
            const material = materialData[rarity];
            const materialGameId = material.game_id;
            const nextRarity = +rarity - 1;
            const nextMaterial = materialData[nextRarity];
            const nextMaterialGameId = nextMaterial?.game_id;

            // Update shortages
            if (materialGameId in finalNeeds) {
                const required = finalNeeds[materialGameId];
                const available = inventory[materialGameId] || 0;
                finalNeeds[materialGameId] = Math.max(0, required - available);
                inventory[materialGameId] = Math.max(0, available - required);
            }

            // Convert surplus to lower rarity
            if (nextMaterialGameId) {
                const surplus = inventory[materialGameId] || 0;
                const converted = surplus * 3;
                inventory[materialGameId] = 0;
                inventory[nextMaterialGameId] = (inventory[nextMaterialGameId] || 0) + converted;
            }
        }
    }
    return finalNeeds;
};
