import { performItemSynthesisWithNeeds, backwardConversion } from './synthesis';

/**
 * Calculates materials using forward and backward synthesis.
 */
export const calculateMaterials = (inventory, tieredMaterials, shortages) => {
  console.log("[Debug] Initial Inventory:", inventory);
  console.log("[Debug] Initial Shortages:", shortages);

  const forwardResult = performItemSynthesisWithNeeds(inventory, tieredMaterials, shortages);
  //console.log("[Debug] After Forward Synthesis:", forwardResult);

  const  {updatedInventory, synthesisResults, rawNeedResults} = forwardResult;

  const finalNeeds = backwardConversion(forwardResult.updatedInventory, tieredMaterials, shortages);
  console.log("[Debug] Final Needs After Backward Conversion:", finalNeeds);

  const synthesizedPerGameId = {};
  for (const [gameId, { synthesized }] of Object.entries(forwardResult.synthesisResults)) {
    synthesizedPerGameId[gameId] = synthesized;
  }

  console.log("[Debug] Synthesized Per Game ID:", synthesizedPerGameId);

  const rawNeedPerGameId = {};

  for (const [gameId, { rawNeed }] of Object.entries(forwardResult.rawNeedResults)) {
    rawNeedPerGameId[gameId] = rawNeed;
  }

  // console.log("[Debug] Raw Need :", rawNeedPerGameId);

  return {
    final_inventory: forwardResult.updatedInventory,
    synthesis_results: forwardResult.synthesisResults,
    final_needs: finalNeeds,
    synthesized_per_game_id: synthesizedPerGameId,
    raw_needs: rawNeedPerGameId
  };
};

/**
 * Utility: merges multiple material maps.
 */
export function mergeMaterials(...materialSources) {
  const merged = {};
  materialSources.forEach((source) => {
    Object.entries(source).forEach(([material, amount]) => {
      merged[material] = (merged[material] || 0) + amount;
    });
  });
  return merged;
}

/**
 * Utility: extracts level difference range
 */
export const getLevelRangeDiff = (arrayData, currentLevel, targetLevel) => {
  const sortedData = arrayData.sort((a, b) =>
    a.level.localeCompare(b.level, undefined, { numeric: true })
  );

  const currentLevelIndex = sortedData.findIndex((arr) => arr.level === currentLevel);
  const targetLevelIndex = sortedData.findIndex((arr) => arr.level === targetLevel);

  if (currentLevelIndex === -1 || targetLevelIndex === -1) {
    console.warn('Invalid level range provided.');
    return [];
  }

  return [...new Set(sortedData.slice(currentLevelIndex + 1, targetLevelIndex + 1))];
};