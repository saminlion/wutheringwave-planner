import costs from '../../data/costs.json';
import { processMaterials } from './core';
import { getLevelRangeDiff } from './plannerCalc';

export function calculateWeaponMaterials(settings, weaponInfo, rarity) {
  const levelSet = costs[0].weapon[`level_${rarity}`];
  if (!levelSet) return {};

  const levels = getLevelRangeDiff(
    Object.entries(levelSet).map(([level, data]) => ({ level, ...data })),
    settings.currentLevel,
    settings.targetLevel
  );

  const result = {};
  levels.forEach((levelData) => {
    for (const [key, value] of Object.entries(levelData)) {
      if (key !== 'level') processMaterials(result, key, value, weaponInfo);
    }
  });

  return result;
}