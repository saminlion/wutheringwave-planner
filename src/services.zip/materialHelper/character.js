import costs from '../../data/costs.json';
import { processMaterials } from './core';
import { getLevelRangeDiff, mergeMaterials } from './plannerCalc';

export function calculateCharacterMaterials(settings, characterInfo) {
  const level = calculateLevelMaterials(settings, characterInfo);
  const skill = calculateSkillMaterials(settings, characterInfo);
  const passive = calculatePassiveMaterials(settings, characterInfo);
  return mergeMaterials(level, skill, passive);
}

export function calculateLevelMaterials(settings, characterInfo) {
  const levels = getLevelRangeDiff(
    Object.entries(costs[0].character.level).map(([level, data]) => ({ level, ...data })),
    settings.currentLevel,
    settings.targetLevel
  );

  const result = {};
  levels.forEach((levelData) => {
    for (const [key, value] of Object.entries(levelData)) {
      if (key !== 'level') processMaterials(result, key, value, characterInfo);
    }
  });
  return result;
}

export function calculateSkillMaterials(settings, characterInfo) {
  const result = {};
  for (const key in settings.activeSkills) {
    if (!key.endsWith('_current_level')) continue;

    const base = key.replace('_current_level', '');
    const current = parseInt(settings.activeSkills[key], 10);
    const target = parseInt(settings.activeSkills[`${base}_target_level`], 10);
    if (isNaN(current) || isNaN(target) || current >= target) continue;

    for (let i = current + 1; i <= target; i++) {
      const skillCosts = costs[0].character.skill[i];
      for (const [k, v] of Object.entries(skillCosts)) {
        processMaterials(result, k, v, characterInfo);
      }
    }
  }
  return result;
}

export function calculatePassiveMaterials(settings, characterInfo) {
  const result = {};
  for (const [key, isEnabled] of Object.entries(settings.passiveSkills || {})) {
    if (!isEnabled) continue;

    let passiveCosts;
    if (key.startsWith('passive_ability')) {
      const idx = key.split('_').pop();
      passiveCosts = costs[0].character.passive.skill[idx];
    } else if (key.startsWith('bonus_stats_')) {
      const tier = key.split('_')[2];
      passiveCosts = costs[0].character.passive.stat[tier];
    }

    if (passiveCosts) {
      for (const [k, v] of Object.entries(passiveCosts)) {
        processMaterials(result, k, v, characterInfo);
      }
    }
  }
  return result;
}